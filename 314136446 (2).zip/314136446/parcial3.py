#!/usr/bin/env python
# coding: utf-8

# ## Parcial 3
# ### Dehesa Corona Valeria Carolina
# #### Nombre del programa : parcial3.py
# #### Elaborado en Jupyter Notebook

# **Bibliotecas adicionales:**

# In[1]:


import numpy as np
import math
from numpy import linalg as LA


# **1.(2 puntos) Factorizaciones: para esta sección puedes hacer uso de
# las funciones de numpy np.empty_like, np.zeros, shape, linalg.multi_dot, norm, sqrt.**

# **1. (1 punto) Factorización QR: define el código en python necesario para la función que, dada
# una matriz devuelva la factorización QR (empleando el método que gustes, Gram-Schmidt
# o Householder).**

# In[4]:


def factQR(A): #Gram-Schmidt
#Primero buscamos el número de filas y columnas
    n = len(A)
    m = len(A[:, 0])
    
    Q = np.zeros((n,m)) #Inicializamos las matrices resultado
    R = np.zeros((m,m))
    
    a = np.zeros((n,m)) #Matriz auxiliar para las a_i_transpuestas = columna_i - (m_i)
    M = np.zeros((n,m)) #Matriz auxiliar para las m_i = (columnaanterior_de_q_transpuesta * columna_i)*columnaanterior_de_q 
    T = np.zeros((n,m)) #Matriz auxiliar para matrices transpuestas de vectores Q_i

    T[0] = np.transpose(Q[:, 0])
    R[0][1] = np.dot(T[0],A[:, 1])
    M[:, 1] = R[0][1]*Q[:, 0]
    
    for i in range(0,m):
        a[:, i] = A[:, i] - M[:, i]
        Q[:, i] = a[:, i]/normita(a[:, i])
        R[i][i] = normita(a[:, i]) #llenamos la diagonal de la matriz diagonal superior con las normas de a_i = (columna_i) - (columnaanterior_de_q_transpuesta * columna_i)*columnaanterior_de_q 
        
        for j in range(0,m-1):
            if i+1<m:
                T[j] = np.transpose(Q[:, j])
                R[j][i+1] = np.dot(T[j],A[:, i+1])
                M[:, i+1] += R[j][i+1]*Q[:, j]
         
    return Q,R
    
def normita(vec): #función que da la norma 2 de los vectores
    norm = 0
    n = len(vec)
    for i in range(n):
        norm += (vec[i])**2
    return math.sqrt(norm)


# **1.2 (1 punto) Factorización Cholesky: define el código en python necesario para la función
# que, dada una matriz devuelva la factorización de Cholesky.**

# In[9]:


def cholesky(matrix): #Primero buscamos el número de filas y columnas
    
    n = len(matrix)
    L = np.zeros((n,n)) #Inicializamos matriz resultante
 
    # Descomponemos la matriz en una triangular inferior
    for i in range(n): 
        for j in range(i + 1): 
            sum = 0;
 
            # suma para diagonales
            if (j == i): 
                for k in range(j):
                    sum += pow(L[j][k], 2);
                L[j][j] = int(math.sqrt(matrix[j][j] - sum));
            else:
                 
                # Evaluamos L(i, j) usando L(j, j)
                for h in range(j):
                    sum += (L[i][h] *L[j][h]);
                if(L[j][j] > 0):
                    L[i][j] = int((matrix[i][j] - sum) /L[j][j])
    return L


# In[10]:


def main():
    print("Factorización QR")
    mat = np.array([[1,2,3],[-1,10,-3],[0,-2,3]])
    print("Matriz original")
    print(mat) #imprimimos matriz original
    Q,R = factQR(mat)
    print("Matriz Q")
    print(Q)
    print("Matriz R")
    print(R)
    
    print("Ahora revisamos las resultantes de la librería numpy.linalg")
    k,m = LA.qr(mat) 
    print("Matriz Q")
    print(k)
    print("Matriz R")
    print(m)
    
    print("Cholesky")
    matrix = np.array([[4, 12, -16],
          [12, 37, -43],
          [-16, -43, 98]])
    lower = cholesky(matrix)
    transpuesta = np.transpose(lower)
    print("Matriz Triangular inferior")
    print(lower)
    print("Matriz Triangular inferior Transpuesta")
    print(transpuesta)

    
    
print(main())


# In[ ]:




